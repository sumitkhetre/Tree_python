
 #!/usr/bin/python3

# Author: Nilesh Ghule <nilesh@sunbeaminfo.com>
# sql_demos -> demo03.py
# Date: 09-11-2020


from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder\
    .config("spark.sql.shuffle.partitions", "2")\
    .appName("demo04")\
    .master("local[2]")\
    .getOrCreate()

filePath = "/home/sunbeam/hadoop-2.7.3/LICENSE.txt"
file = spark.read.text(filePath)

file.createOrReplaceTempView("file")

sql = "SELECT explode(split(lower(value), '[^a-z]')) AS word FROM file"
words = spark.sql(sql)

words.createOrReplaceTempView("words")

sql = "SELECT word, COUNT(word) FROM words GROUP BY word ORDER BY 2 DESC LIMIT 20"
result = spark.sql(sql)

result.show()



spark.stop()





